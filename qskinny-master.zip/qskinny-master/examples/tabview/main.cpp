/******************************************************************************
 * QSkinny - Copyright (C) The authors
 *           SPDX-License-Identifier: BSD-3-Clause
 *****************************************************************************/

#include <SkinnyShortcut.h>

#include <QskFocusIndicator.h>
#include <QskLinearBox.h>
#include <QskObjectCounter.h>
#include <QskPushButton.h>
#include <QskSkin.h>
#include <QskTabView.h>
#include <QskTextLabel.h>
#include <QskWindow.h>
#include <QskShortcutMap.h>
#include <QskFontRole.h>

#include <QGuiApplication>

class Label : public QskTextLabel
{
  public:
    Label( const QString& text, QQuickItem* parent = nullptr )
        : QskTextLabel( text, parent )
    {
        setTextColor( Qt::darkRed );
        setFontRole( QskFontRole::Headline );
        setAlignment( Qt::AlignCenter );
    }
};

class TabView : public QskTabView
{
  public:
    TabView( QQuickItem* parent = nullptr )
        : QskTabView( parent )
    {
        for ( int i = 0; i < 10; i++ )
        {
            if ( i == 4 )
            {
                const auto text = QStringLiteral( "Another Tab" );
                addTab( text, new Label( text ) );
            }
            else
            {
                const auto text = QString( "Tab %1" ).arg( i + 1 );
                addTab( text, new Label( text ) );
            }
        }

        setTabEnabled( 2, false );
        setCurrentIndex( 4 );
    }

    void appendTab()
    {
        const auto text = QString( "Tab %1" ).arg( count() + 1 );
        addTab( text, new Label( text ) );
    }

    void removeLastTab()
    {
        if ( count() > 0 )
            removeTab( count() - 1 );
    }

    void rotate()
    {
        using namespace Qt;
        const Edge edges[] = { TopEdge, RightEdge, BottomEdge, LeftEdge };

        for ( int i = 0; i < 4; i++ )
        {
            if ( tabBarEdge() == edges[i] )
            {
                setTabBarEdge( edges[ ( i + 1 ) % 4 ] );
                break;
            }
        }
    }
};

int main( int argc, char* argv[] )
{
#ifdef ITEM_STATISTICS
    QskObjectCounter counter( true );
#endif

    QGuiApplication app( argc, argv );

    SkinnyShortcut::enable( SkinnyShortcut::AllShortcuts );

    auto tabView = new TabView();

    auto rotateButton = new QskPushButton( "Rotate" );
    rotateButton->setFocus( true );
    QObject::connect( rotateButton, &QskPushButton::clicked,
        tabView, &TabView::rotate );

    auto autoFitButton = new QskPushButton( "Fit Tabs" );
    autoFitButton->setCheckable( true );
    QObject::connect( autoFitButton, &QskPushButton::toggled,
        tabView, &QskTabView::setAutoFitTabs );

    auto addButton = new QskPushButton( "Add" );
    QObject::connect( addButton, &QskPushButton::clicked,
        tabView, &TabView::appendTab );

    auto removeButton = new QskPushButton( "Remove" );
    QObject::connect( removeButton, &QskPushButton::clicked,
        tabView, &TabView::removeLastTab );

    auto buttonBox = new QskLinearBox( Qt::Horizontal );
    buttonBox->addItem( rotateButton );
    buttonBox->addItem( autoFitButton );
    buttonBox->addItem( addButton );
    buttonBox->addItem( removeButton );
    buttonBox->setSizePolicy( QskSizePolicy::Fixed, QskSizePolicy::Fixed );

    auto layoutBox = new QskLinearBox( Qt::Vertical );
    layoutBox->setDefaultAlignment( Qt::AlignLeft );
    layoutBox->setPadding( 20 );
    layoutBox->setSpacing( 10 );
    layoutBox->setPanel( true );
    layoutBox->addItem( buttonBox );
    layoutBox->addItem( tabView );

    auto focusIndicator = new QskFocusIndicator();

    QskWindow window;
    window.resize( 800, 600 );
    window.addItem( layoutBox );
    window.addItem( focusIndicator );

    window.show();

    for ( int i = 0; i < 10; i++ )
    {
        QskShortcutMap::addShortcut( Qt::Key_F1 + i, false,
            [tabView, i] { tabView->removeTab( i ); } );
    }

    return app.exec();
}
